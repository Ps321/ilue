<?php
$servername = "localhost";
$username = "u248944339_dice10";
$password = "Diceten@10";
$dbname = "u248944339_dice10";
// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


?>