<?php


include "../../connection.php";
session_start();


?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Admin</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="../../assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../../assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="../../assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="../../assets/images/favicon.ico" />
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:../../partials/_navbar.html -->
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
      <!--    <a class="navbar-brand brand-logo" href="../../index.html"><img src="../../assets/images/logo.svg" alt="logo" /></a>
          <a class="navbar-brand brand-logo-mini" href="../../index.html"><img src="../../assets/images/logo-mini.svg" alt="logo" /></a>
        --></div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
          <div class="search-field d-none d-md-block">
            <form class="d-flex align-items-center h-100" action="#">
              <div class="input-group">
                <div class="input-group-prepend bg-transparent">
                  <i class="input-group-text border-0 mdi mdi-magnify"></i>
                </div>
                <input type="text" class="form-control bg-transparent border-0" placeholder="Search projects">
              </div>
            </form>
          </div>
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
              <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-bs-toggle="dropdown" aria-expanded="false">
                <div class="nav-profile-img">
                  <img src="../../assets/images/faces/face1.jpg" alt="image">
                  <span class="availability-status online"></span>
                </div>
                <div class="nav-profile-text">
                  <p class="mb-1 text-black">Admin</p>
                </div>
              </a>
              <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
                <a class="dropdown-item" href="#">
                  <i class="mdi mdi-cached me-2 text-success"></i> Activity Log </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="../../../index.php">
                  <i class="mdi mdi-logout me-2 text-primary"></i> Signout </a>
              </div>
            </li>
            <li class="nav-item d-none d-lg-block full-screen-link">
              <a class="nav-link">
                <i class="mdi mdi-fullscreen" id="fullscreen-button"></i>
              </a>
            </li>
            
            <li class="nav-item nav-logout d-none d-lg-block">
              <a class="nav-link" href="#">
                <i class="mdi mdi-power"></i>
              </a>
            </li>
           
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
            <ul class="nav">
                <li class="nav-item nav-profile">
                  <a href="#" class="nav-link">
                    <div class="nav-profile-image">
                      <img src="../../assets/images/faces/face1.jpg" alt="profile">
                      <span class="login-status online"></span>
                      <!--change to offline or busy as needed-->
                    </div>
                    <div class="nav-profile-text d-flex flex-column">
                      <span class="font-weight-bold mb-2">Admin</span>
                      <span class="text-secondary text-small">Admin</span>
                    </div>
                    <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="../../index.php">
                    <span class="menu-title">Dashboard</span>
                    <i class="mdi mdi-home menu-icon"></i>
                  </a>
                </li>
    
                <li class="nav-item">
                  <a class="nav-link" href="players_info.php">
                    <span class="menu-title">Players</span>
                    <i class="mdi mdi-account menu-icon"></i>
                  </a>
                </li>
    
                <!--<li class="nav-item">-->
                <!--  <a class="nav-link" href="clients_info.php">-->
                <!--    <span class="menu-title">Clients</span>-->
                <!--    <i class="mdi mdi-account-multiple-outline menu-icon"></i>-->
                <!--  </a>-->
                <!--</li>-->
    
               
    
                <li class="nav-item">
                  <a class="nav-link" href="game_statement.php">
                    <span class="menu-title">Game statement</span>
                    <i class="mdi mdi-book menu-icon"></i>
                  </a>
                </li>
               
               
              </ul>
        </nav>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="row">
                <div class="col-lg-12 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body">
                      <h6 class="card-title">Result</h6>
                     
                            </p>
                      <table class="table">
                        <thead>
                          <tr>
                           
                            <th> ID</th>
                            <th> Player1 Name</th>
                            <th> Player1_no</th>
                            <th> Player2 Name</th>
                            <th>Player2_no</th>
                            <th>Bet</th>
                            <th>Winner</th>
                          </tr>
                        </thead>
                        <tbody>
                             <?php
                             $a=$_SESSION["loginname"];
                      $sql="Select * from results ORDER BY id DESC";
                      $result = $conn->query($sql);

                      if ($result->num_rows > 0) {
                        // output data of each row
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>".$row['id']."</td>";
                             echo "<td>".$row['player1']."</td>";
                              echo "<td>".$row['player1_no']."</td>";
                               echo "<td>".$row['player2']."</td>";
                            echo "<td>".$row['player2_no']."</td>";
                            echo "<td> ".$row['bettedamount']."</td>";
                            echo "<td> ".$row['winner']."</td>";
                            echo "</tr>";
                         
                        }
                      } else {
                        //  echo $sql;
                        echo "0 results";
                      } 
                    ?>
                          
                         
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
           </div>  

          </div>
          
          <script>

const buttons = document.querySelectorAll('.btn.btn-outline-primary.btn-fw');
const buttons2 = document.querySelectorAll('.btn.btn-outline-danger.btn-fw');

buttons.forEach(button => {
  button.addEventListener('click', () => {
    // Get the ID and Name values from the button's data attributes

    const id = button.value;
    

    // Send a POST request to the PHP script with the ID and Name values
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'approvetransaction.php');
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send(`id=${id}`);
    
   var interval = setInterval(myURL, 500);
   
  });
});



buttons2.forEach(button => {
  button.addEventListener('click', () => {
    // Get the ID and Name values from the button's data attributes

    const id = button.value;
    

    // Send a POST request to the PHP script with the ID and Name values
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'rejecttransaction.php');
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send(`id=${id}`);
    
   var interval = setInterval(myURL, 500);
   
  });
});

function myURL(){
   location.reload();
}

          </script>
      
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
          
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="../../assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="../../assets/js/off-canvas.js"></script>
    <script src="../../assets/js/hoverable-collapse.js"></script>
    <script src="../../assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <!-- End custom js for this page -->
  </body>
</html>