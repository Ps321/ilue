<?php
$id=$_POST["id"];
$separator = '-';
$output = explode($separator, $id);
$number=$output[0];
$value=$output[1];
$type=$output[2];
echo $number;

//$id=4;
$servername = "localhost";
$username = "u248944339_dice10";
$password = "Diceten@10";
$db = "u248944339_dice10";
// Create connection
$conn = new mysqli($servername, $username, $password,$db);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "Select * from withdraw_request WHERE number='$number' AND amount=$value AND status='Pending' LIMIT 1";
$result = $conn->query($sql);
if ($result->num_rows > 0) {

  // output data of each row
  $row = $result->fetch_assoc();
  $request_amount=$row["amount"];
  // $username=$row["user_id"];

  $sql1 = "Select * from users WHERE number='$number'";
    $result1 = $conn->query($sql1);
    if ($result1->num_rows > 0) {
        $row1 = $result1->fetch_assoc();
        
        if($row1["balance"] >= $request_amount && $type=="0"){
           $aa=$row1['balance'];
            $sql2 = "Update users Set balance=$aa-$request_amount where number='$number'";
           $result2 = $conn->query($sql2);
           
            
                 
             $sql3 = "Update withdraw_request Set status='Approved' where number='$number' AND amount=$value AND status='Pending' LIMIT 1  ";
            $result3 = $conn->query($sql3);
            
        //     if ($result3->num_rows > 0) {
        //         echo "done";
            
        // }
        http_response_code(200);
        }
        else{
             http_response_code(201);
            $sql3 = "Update withdraw_request Set status='Rejected' where number='$number' AND amount=$value AND status='Pending' LIMIT 1 ";
            $result3 = $conn->query($sql3);
            if ($result3->num_rows > 0) {
                echo "done";
            }
        }
        
    
    } 
} else {
  echo "Error";
}


$conn->close();

?>