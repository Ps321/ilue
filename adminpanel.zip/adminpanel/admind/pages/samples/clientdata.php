<?php
include "../../connection.php";
session_start();
$a=$_SESSION['playerid'];
?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> Admin</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="../../assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../../assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="../../assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="../../assets/images/favicon.ico" />
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:../../partials/_navbar.html -->
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
      <!--    <a class="navbar-brand brand-logo" href="../../index.html"><img src="../../assets/images/logo.svg" alt="logo" /></a>
          <a class="navbar-brand brand-logo-mini" href="../../index.html"><img src="../../assets/images/logo-mini.svg" alt="logo" /></a>
        --></div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
          <div class="search-field d-none d-md-block">
            <form class="d-flex align-items-center h-100" action="#">
              <div class="input-group">
                <div class="input-group-prepend bg-transparent">
                  <i class="input-group-text border-0 mdi mdi-magnify"></i>
                </div>
                <input type="text" class="form-control bg-transparent border-0" placeholder="Search projects">
              </div>
            </form>
          </div>
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
              <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-bs-toggle="dropdown" aria-expanded="false">
                <div class="nav-profile-img">
                  <img src="../../assets/images/faces/face1.jpg" alt="image">
                  <span class="availability-status online"></span>
                </div>
                <div class="nav-profile-text">
                  <p class="mb-1 text-black">Admin</p>
                </div>
              </a>
              <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
                <a class="dropdown-item" href="#">
                  <i class="mdi mdi-cached me-2 text-success"></i> Activity Log </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="http://jackpotcasinogame.in/">
                  <i class="mdi mdi-logout me-2 text-primary"></i> Signout </a>
              </div>
            </li>
            <li class="nav-item d-none d-lg-block full-screen-link">
              <a class="nav-link">
                <i class="mdi mdi-fullscreen" id="fullscreen-button"></i>
              </a>
            </li>
            
            <li class="nav-item nav-logout d-none d-lg-block">
              <a class="nav-link" href="#">
                <i class="mdi mdi-power"></i>
              </a>
            </li>
           
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:../../partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <nav class="sidebar sidebar-offcanvas" id="sidebar">
            <ul class="nav">
                <li class="nav-item nav-profile">
                  <a href="#" class="nav-link">
                    <div class="nav-profile-image">
                      <img src="../../assets/images/faces/face1.jpg" alt="profile">
                      <span class="login-status online"></span>
                      <!--change to offline or busy as needed-->
                    </div>
                    <div class="nav-profile-text d-flex flex-column">
                      <span class="font-weight-bold mb-2">Admin</span>
                      <span class="text-secondary text-small">Admin</span>
                    </div>
                    <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="../../index.php">
                    <span class="menu-title">Dashboard</span>
                    <i class="mdi mdi-home menu-icon"></i>
                  </a>
                </li>
    
                <li class="nav-item">
                  <a class="nav-link" href="players_info.php">
                    <span class="menu-title">Players</span>
                    <i class="mdi mdi-account menu-icon"></i>
                  </a>
                </li>
    
                <li class="nav-item">
                  <a class="nav-link" href="clients_info.php">
                    <span class="menu-title">Clients</span>
                    <i class="mdi mdi-account-multiple-outline menu-icon"></i>
                  </a>
                </li>
                 <li class="nav-item">
                  <a class="nav-link" href="superclients_info.php">
                    <span class="menu-title">Super Clients</span>
                    <i class="mdi mdi-account-multiple-outline menu-icon"></i>
                  </a>
                </li>
    
    
                <li class="nav-item">
                  <a class="nav-link" href="money.php">
                    <span class="menu-title">Money</span>
                    <i class="mdi mdi-account-card-details menu-icon"></i>
                  </a>
                </li>
    
                <li class="nav-item">
                  <a class="nav-link" href="game_statement.php">
                    <span class="menu-title">Game statement</span>
                    <i class="mdi mdi-book menu-icon"></i>
                  </a>
                </li>
               
              </ul>
        </nav>
        </nav>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">


            <?php
            if(isset($_POST['updatecoins'])){
                $points=$_POST['playerpoints'];
                $sql="Update clients SET points=$points where id=$a";
                 if ($conn->query($sql) === TRUE) {
                  echo "<p style='color:green; font-weight:800'>Updated Coins successfully</p>";
                } else {
                  echo "Error: " . $sql . "<br>" . $conn->error;
                }
            }
            
            
            
             if(isset($_POST['addcoinsbtn'])){
                $addcoins=$_POST['addcoins'];
                $sql="Update clients SET points=points+$addcoins where id=$a";
                 if ($conn->query($sql) === TRUE) {
                  echo "<p style='color:green; font-weight:800'>Added Coins successfully</p>";
                } else {
                  echo "Error: " . $sql . "<br>" . $conn->error;
                }
            }
            
            if(isset($_POST['updatedetails'])){
                  $name = $_POST["name"];
                $aadhar = $_POST["aadhar"];
                $pan = $_POST["pan"];
                $address = $_POST["address"];
                $bname = $_POST["bname"];
                $accnumber = $_POST["accnumber"];
                $ifsc = $_POST["ifsc"];
                $sql="Update clients_kyc SET fullname='$name',aadhar='$aadhar',pan='$pan',address='$address',bankname='$bname',accnumber='$accnumber',ifsc='$ifsc' where id=$a";
                 if ($conn->query($sql) === TRUE) {
                  echo "<p style='color:green; font-weight:800'>Data Updated  successfully</p>";
                } else {
                  echo "Error: " . $sql . "<br>" . $conn->error;
                }
            }
            
            
            if(isset($_POST['changepassword'])){
                $pwchange=$_POST["passwordchange"];
                $sql="Update clients SET password=$pwchange where id=$a";
                 if ($conn->query($sql) === TRUE) {
                  echo "<p style='color:green; font-weight:800'>Password Reset  successfully</p>";
                } else {
                  echo "Error: " . $sql . "<br>" . $conn->error;
                }
            }
            
            ?>




            <div class="row">
            
             
              <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Player ID</h4>
                   <div class="form-group">
                       <?php
                       echo "<p style='font-weight: 600;'>".$a."</p>";
                       ?>
                      
                    <!--  <input type="text" class="form-control form-control-lg" placeholder="No of coins" aria-label="Username" readonly>-->
                    </div>
                    
                  </div>
                </div>
               </div>

       
              <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Coins</h4>
                      <form method="POST" action="">
                   <div class="form-group">
                      <label>Change Player Coins</label>
                   
                    
                      <?php
                      $sql="Select * from clients where id=".$a;
                       $result = $conn->query($sql);

                      if ($result->num_rows > 0) {
                        
                        while($row = $result->fetch_assoc()) {
                            echo "<input type='text' class='form-control form-control-lg' name='playerpoints' placeholder='No of coins' value=".$row['points']." aria-label='Username'>";
                          
                         
                        }
                      } else {
                        echo "0 results";
                      } 
                      ?>
                  
                    </div>
                    <button type="submit" name="updatecoins" class="btn btn-gradient-primary me-2">Update</button>
                 </form>
                   <form method="POST" action="">
                  <div class="form-group">

                      <br>
                      <br>
                      
                      <label>Number Of Coins</label>
                      <input type="text" name='addcoins' class="form-control form-control-lg" placeholder="No of coins" aria-label="Username">
                    </div>
                   <button type="submit" name='addcoinsbtn' class="btn btn-gradient-primary me-2">Add</button>
                 </form>
                  </div>
                </div>
               </div>
             
             
               <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Passwords</h4>
                     <form method="POST" action="">
                   
                   <div class="form-group">
                      <label>Change Password</label>
                      <input type="text" class="form-control form-control-lg" name='passwordchange' placeholder="Change Password" aria-label="Username">
                    </div>
                    <button type="submit" name='changepassword' class="btn btn-gradient-primary me-2">Change Password</button>
                  </form>
                  
                  </div>
                </div>
               </div>
             
              
              <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Player KYC</h4>
                    <p class="card-description"> Player Details </p>
                    <?php
                        $sql="select * from clients_kyc where id=$a";
                          $result = $conn->query($sql);

                      if ($result->num_rows > 0) {
                        // output data of each row
                       if($row = $result->fetch_assoc()) {
                       ?>
                       <?php
                        
                           
                       }
                      } else {
                        echo "0 results";
                      }
                    ?>
                    <form class="forms-sample" method="POST" action="">
                      <div class="form-group">
                        <label for="exampleInputName1">Full Name</label>
                        <input type="text" class="form-control" name="name" id="exampleInputName1" value=<?php echo $row['fullname']; ?> >
                      </div>
                      <div class="form-group">
                        <label for="exampleInputEmail3">Aadhar Number</label>
                        <input type="text" class="form-control" name="aadhar" id="exampleInputEmail3" value=<?php echo $row['aadhar']; ?> >
                      </div>
                      <div class="form-group">
                        <label for="exampleInputPassword4">Pan Number</label>
                        <input type="text" class="form-control" name="pan" id="exampleInputPassword4" value=<?php echo $row['pan']; ?> >
                      </div>

                      
                      <div class="form-group">
                        <label for="exampleSelectGender">Address</label>
                        <input type="text" class="form-control" name="address" id="exampleInputPassword4" value=<?php echo $row['address']; ?> >
             
                      </div>
                      
                      <div class="form-group">
                        <label for="exampleInputName5">Bank Name</label>
                        <input type="text" class="form-control" name="bname" id="exampleInputName5" value=<?php echo $row['bankname']; ?> >
                      </div>

                      <div class="form-group">
                        <label for="exampleInputName6">Account Number</label>
                        <input type="text" class="form-control" name="accnumber" id="exampleInputName1" value=<?php echo $row['accnumber']; ?> >
                      </div>

                      <div class="form-group">
                        <label for="exampleInputName1">IFSC Number</label>
                        <input type="text" class="form-control" name="ifsc" id="exampleInputName1" value=<?php echo $row['ifsc']; ?> >
                      </div>
                      
                    
                      <button type="submit" name="updatedetails" class="btn btn-gradient-primary me-2">Update</button>
                      <button class="btn btn-light">Cancel</button>
                    </form>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
          
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="../../assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="../../assets/js/off-canvas.js"></script>
    <script src="../../assets/js/hoverable-collapse.js"></script>
    <script src="../../assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <!-- End custom js for this page -->
  </body>
</html>