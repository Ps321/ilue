<?php
$id=$_POST["id"];
//$id=4;
$servername = "localhost";
$username = "u499016005_roulette";
$password = "Roulette@123";
$db="u499016005_roulette";
// Create connection
$conn = new mysqli($servername, $username, $password,$db);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


                 
             $sql3 = "Update user_points_request Set status='Rejected' where id=$id ";
            $result3 = $conn->query($sql3);
            echo $sql2;
            if ($result3->num_rows > 0) {
                echo "done";
            
        }
 
   

$conn->close();

?>