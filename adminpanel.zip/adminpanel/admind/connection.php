<?php
$servername = "localhost";
$username = "u248944339_dice10";
$password = "Diceten@10";
$db = "u248944339_dice10";
// Create connection
$conn = new mysqli($servername, $username, $password,$db);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


?>