<?php
include "connection.php";
session_start();

 if(isset($_POST["adminlogin"])){
      $_SESSION["loginname"]="admin";
	        $username=$_POST["username"];
        $pw=$_POST["password"];
       if($username=="admin" && $pw=="admin"){
           header('Location: ./admind/index.php');
       }
      
	         $sql="Select * from adminlogin where username='$username' AND password='$pw'";
                    $result = $conn->query($sql);

                      if ($result->num_rows > 0) {
                           if($row = $result->fetch_assoc()) {
                          
                          header('Location: ./admind/index.php');
                      }
                      }
                      else{
                          echo $sql;
                      }
}














  if(isset($_POST["clientlogin"])){
	        $username=$_POST["cusername"];
            $pw=$_POST["cpassword"];
	         $sql="Select * from clients where username='$username' AND password='$pw'";
              $result = $conn->query($sql);

                      if ($result->num_rows > 0) {
                          if($row = $result->fetch_assoc()) {
                          $_SESSION["clientid"] = $row["id"];
                           $_SESSION["loginname"]=$row["username"];
                          $_SESSION["clientpoints"] = $row["points"];
                          header('Location: http://jackpotcasinogame.in/clientd/index.php');
                }      }
                      else{
                          echo $sql;
                      }
}



 
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<style>
		body {
			background-color: #f7f7f7;
			font-family: Arial, sans-serif;
		}
		h1 {
			text-align: center;
			margin-top: 50px;
			color: #333;
		}
		.container {
			display: flex;
			flex-wrap: wrap;
			justify-content: center;
			align-items: center;
			height: 100vh;
		}
		form {
			display: flex;
			flex-direction: column;
			align-items: center;
			padding: 30px;
			background-color: #fff;
			box-shadow: 0px 3px 10px rgba(0,0,0,0.2);
			border-radius: 5px;
		}
		label {
			display: block;
			margin-bottom: 10px;
			color: #333;
			font-size: 14px;
			font-weight: bold;
		}
		input[type="text"],
		input[type="password"] {
			width: 100%;
			padding: 10px;
			margin-bottom: 20px;
			border-radius: 5px;
			border: none;
			background-color: #f5f5f5;
			font-size: 16px;
			color: #333;
		}
		button {
			background-color: #4CAF50;
			color: #fff;
			padding: 12px 20px;
			border: none;
			border-radius: 5px;
			cursor: pointer;
			font-size: 16px;
			transition: background-color 0.3s ease;
		}
		button:hover {
			background-color: #3e8e41;
		}
		.error {
			color: red;
			font-size: 12px;
			margin-top: 5px;
		}
	</style>
	<style>
		.container {
			display: flex;
			flex-wrap: wrap;
			justify-content: center;
			align-items: center;
			height: 100vh;
		}
		.form {
			display: flex;
			flex-direction: column;
			align-items: center;
			width: 50%;
			padding: 20px;
			box-sizing: border-box;
			background-color: #f0f0f0;
			border: 1px solid #ccc;
		}
		label{
		    color:white;
		}
	</style>
</head>
<body>
	<div class="container" style="background-image: url('bg32.jpg'); background-repeat: no-repeat; background-size: cover; overflow-y:hidden; background-size: 100% 100%;">
	  
	    
		<form class="form" action="" method="POST" style="background-color:rgba(0,0,0,0.4)">
			<h2 style="color:white">Admin Login</h2>
			<label for="admin-username">Username:</label>
			<input type="text" name="username" required>
			<label for="password">Password:</label>
			<input type="password" name="password" required>
			<button type="submit" name="adminlogin" onclick=setitem()>Login</button>
		</form>
	
	
		
		
	</div>
	<script>
	   function setitem(){
	       // Set a value
sessionStorage.setItem('loginname', 'admin');

	    }
	    
	</script>
</body>
</html>
